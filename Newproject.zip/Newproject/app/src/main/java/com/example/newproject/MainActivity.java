package com.example.newproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {



    EditText editText1, editText2;
    Button Login;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        editText1=findViewById(R.id.editTextTextEmailAddress);
        editText2=findViewById(R.id.editTextTextPassword);
        Login=findViewById(R.id.button);

        Login.setOnClickListener(new View.OnClickListener(){



            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,homepage.class);
                startActivity(intent);
                //String phone = editText1.getText().toString();
                String email = editText1.getText().toString();
                String password = editText2.getText().toString();

                boolean check = validateinfo(email,password);
                if(check==true){
                    Toast.makeText(getApplicationContext(), "Data is valid", Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(getApplicationContext(), "Sorry, check information again", Toast.LENGTH_SHORT).show();
                }

            }
        });

    }

    private boolean validateinfo(String email, String password) {
        /* if (phone.length() == 0){
            editText1.requestFocus();
            editText1.setError("Field can not be empty");
            return false;
         }
         else if(!phone.matches( "^[+][0-9]{10,13}$")){
            editText1.requestFocus();
            editText1.setError("Incorrect Format");
            return false;
         }*/
         if(email.length()==0) {
            editText1.requestFocus();
            editText1.setError("Field can not be empty!");
            return false;
        }
         else if(!email.matches("[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+")){
             editText1.requestFocus();
             editText1.setError("Enter valid email");
             return false;
         }
         else if(password.length()<=5){
             editText2.requestFocus();
             editText2.setError("Minimum six charaters required");
             return false;
        }
         else{
             return true;
        }




    }
}