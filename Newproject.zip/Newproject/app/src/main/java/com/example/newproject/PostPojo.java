package com.example.newproject;

import android.location.Address;

public class PostPojo {
    private float id;
    private String name;
    private String username;
    private String email;
    private Address AddressObject;
    private String phone;
    private String website;
    private String CompanyObject;


    public float getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getUsername() {
        return username;
    }

    public String getEmail() {
        return email;
    }

    public String getAddress() {
        return String.valueOf(AddressObject);
    }

    public String getPhone() {
        return phone;
    }

    public String getWebsite() {
        return website;
    }

    public String getCompany() {
        return CompanyObject;
    }
}

