package com.example.newproject;

import android.app.LauncherActivity;
import android.content.Context;
import android.location.Address;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.ViewHolder> {

    private List<PostPojo> getposts;
    private Context context;

    public MyAdapter(List<PostPojo> getposts, Context context) {
        this.getposts = getposts;
        this.context = context;
    }

    public MyAdapter(homepage homepage, List<PostPojo> postList) {
    }

    @NonNull
    @Override
    public MyAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.activity_homepage,parent,false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull MyAdapter.ViewHolder holder, int position) {
        PostPojo postPojo = getposts.get(position);

        holder.recyclerView.setTextAlignment((int) postPojo.getId());
        holder.recyclerView.setTextAlignment(Integer.parseInt(postPojo.getName()));
        holder.recyclerView.setTextAlignment(Integer.parseInt(postPojo.getUsername()));
        holder.recyclerView.setTextAlignment(Integer.parseInt(postPojo.getEmail()));
        holder.recyclerView.setTextAlignment(Integer.parseInt(postPojo.getAddress()));
        holder.recyclerView.setTextAlignment(Integer.parseInt((String) postPojo.getPhone()));
        holder.recyclerView.setTextAlignment(Integer.parseInt(postPojo.getWebsite()));
        holder.recyclerView.setTextAlignment(Integer.parseInt(postPojo.getCompany()));


    }

    @Override
    public int getItemCount() {
        return getposts.size();
    }
    public class ViewHolder extends  RecyclerView.ViewHolder{

        public RecyclerView recyclerView;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            recyclerView = (RecyclerView) itemView.findViewById(R.id.recyclerview);
        }
    }
}
